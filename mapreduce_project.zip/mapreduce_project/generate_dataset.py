import random

words = ["data", "science", "machine", "learning", "big", "analytics", "ai", "model"]

with open("dataset.txt", "w") as f:
    for i in range(500):
        line = " ".join(random.choices(words, k=6))
        f.write(line + "\n")

print("Dataset created successfully")
