from django.shortcuts import render
from collections import defaultdict

def map_reduce(text):
    mapped = []
    for line in text.split('\n'):
        words = line.strip().split()

        for word in words:
            mapped.append((word.lower(),1))

    reduced = defaultdict(int)

    for word,count in mapped:
        reduced[word] += count

    return dict(reduced)


def index(request):
    result = None
    labels = []
    values = []

    if request.method == "POST":
        file = request.FILES['dataset']
        content = file.read().decode("utf-8")

        result = map_reduce(content)

        # Top 10 words
        sorted_words = sorted(result.items(), key=lambda x: x[1], reverse=True)[:10]

        labels = [x[0] for x in sorted_words]
        values = [x[1] for x in sorted_words]

    return render(request,"index.html",{
        "result":result,
        "labels":labels,
        "values":values
    })
