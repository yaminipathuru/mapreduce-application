from django.apps import AppConfig


class MapperappConfig(AppConfig):
    name = 'mapperapp'
